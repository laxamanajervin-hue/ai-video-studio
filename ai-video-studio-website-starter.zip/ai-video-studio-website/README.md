# AI Video Studio — Website Prototype

This is a static website prototype. Open `index.html` in a browser to preview it.

## Publish as a website (GitHub Pages)
1. A GitHub account owner creates a new repository named `ai-video-studio`.
2. Upload `index.html` to the repository's root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose branch `main` and folder `/ (root)`, then save.
6. GitHub will show the published website URL after deployment.

## Important before public launch
This prototype is not a production AI video service. It does not yet connect to a video-generation provider, user authentication, a database, subscriptions, or real payments. Its credit counter is only a browser demo and must not be used to sell credits.

A production version needs:
- A secure backend that stores users, subscriptions, credit balances, and generation jobs.
- Server-side credit deductions and refunds.
- A video-generation API connected through server-side secret keys (never put API keys in `index.html`).
- Payment provider integration and subscription webhooks.
- Privacy policy, terms, data deletion process, and abuse/safety controls.
- Testing on mobile and desktop.

## Android / Google Play
The HTML file alone is not a Play Store app. An Android build (for example, a properly configured web app wrapper or native app) and a signed Android App Bundle (`.aab`) are needed. Play Console registration, required testing, declarations, and submission must be completed by an eligible account holder. A parent/guardian must handle developer registration and legal/payment responsibilities if the developer is under 18.
